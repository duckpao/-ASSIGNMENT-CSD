
import java.util.*;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author nguye
 */
public class Main {
    public static BookList bookList;
    public static int getInt(String msg, int min, int max) {
        Scanner sc = new Scanner(System.in);
        int result ;
        do {
            try {
                System.out.println(msg);
                String in = sc.nextLine();
                if (checkInt(in) != -1) {
                    return checkInt(in);
                }
                result = Integer.parseInt(in);
                if (result < min || result > max) {
                    System.err.println("Invalid number. Number must be greater than or equal to 1" );
                    continue;
                }
                return result;
            } catch (Exception e) {
                System.err.println("Invalid format number. Please try again!");
            }
        } while (true);
        

    }
    public static int checkInt(String in) {
        if (in.matches("\\d+[\\.][0]+")) {
            return Integer.parseInt(in.substring(0, in.indexOf(".")));
        }
        return -1;
    }
    public static void displayMenu() {
        Scanner scanner = new Scanner(System.in);
        int choice; 
        do {
            
            choice = getInt("\n========== Library Management System =========="
                    + "\n1. Load data from file"
                    + "\n2. Input & add to the end"
                    + "\n3. Display all books"
                    + "\n4. Save book list to file"
                    + "\n5. Search by bcode"
                    + "\n6. Delete by bcode"
                    + "\n7. Sort by bcode"
                    + "\n8. Input & add to the beginning"
                    + "\n9. Input & add after position k"
                    + "\n10. Delete by position k"
                    + "\n11. Search by title"
                    + "\n12. Exit"
                    + "\nEnter your choice: ", 1, 12);

            switch (choice) {
                case 1:
                    System.out.print("Load from file successfully~~");
//                    String filename = scanner.nextLine();
                    bookList.loadDataFromFile("C:\\Users\\ASUS\\Downloads\\BookManagement\\BookManagement\\src\\Book.txt");
                    break;

                case 2:
                    System.out.println("Enter book details to add:");
                    Book newBook = bookList.inputBookDetails(scanner);
                    bookList.addLast(newBook);
                    break;

                case 3:
                    System.out.println("Displaying all books:");
                    bookList.display();
                    break;

                case 4:
                    
                    bookList.saveToFile("C:\\Users\\ASUS\\Downloads\\BookManagement\\BookManagement\\src\\Book.txt");
                    System.out.print("Save list to file successfully~~");
                    break;

                case 5:
                    System.out.print("Enter bcode to search: ");
                    String bcode = scanner.nextLine();
                    Book foundBook = bookList.searchByBcode(bcode);
                    if (foundBook != null) {
                        System.out.println("Book found: " + foundBook);
                    } else {
                        System.out.println("Book not found!");
                    }
                    break;

                case 6:
                    System.out.print("Enter bcode to delete: ");
                    String deleteBcode = scanner.nextLine();
                    bookList.removeByBcode(deleteBcode);
                    break;

                case 7:
                    System.out.println("Sorting books by bcode...");
                    bookList.sortByBcode();
                    break;

                case 8:
                    System.out.println("Enter book details to add to the beginning:");
                    Book firstBook = bookList.inputBookDetails(scanner);
                    bookList.addFirst(firstBook);
                    break;

                case 9:
                    System.out.print("Enter position k: ");
                    int k = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    Book bookAfterK = bookList.inputBookDetails(scanner);
                    bookList.addAfterPositionK(k, bookAfterK);
                    break;

                case 10:
                    System.out.print("Enter position k to delete: ");
                    int positionToDelete = scanner.nextInt();
                    bookList.deleteByPositionK(positionToDelete);
                    break;

                case 11:
                    System.out.print("Enter title to search: ");
                    String title = scanner.nextLine();
                    bookList.searchByTitle(title);
                    break;
//
                case 12:
                    System.out.println("Exiting system...");
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice! Please try again.");
                    break;
            }
        } while (choice != 8);

        scanner.close();
    }
    public static void main(String[] args) {
        bookList = new BookList();  
        bookList.loadDataFromFile("C:\\Users\\ASUS\\Downloads\\BookManagement\\BookManagement\\src\\Book.txt");

        displayMenu();

    }
}
