import java.io.*;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Scanner;

class LendingList {
    Node<Lending> head;

    public LendingList() {
        this.head = null;
    }

    // Add lending to the beginning of the list
    public void addLendingToBeginning(Lending lending) {
        Node<Lending> newNode = new Node<>(lending);
        newNode.next = head;
        head = newNode;
    }

    // Load lending data from file
    public void loadFromFile(String fileName) {
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                String bcode = parts[0];
                String rcode = parts[1];
                Date ldate = sdf.parse(parts[2]);
                Date rdate = parts[3].equals("null") ? null : sdf.parse(parts[3]);
                int state = Integer.parseInt(parts[4]);
                
                Lending lending = new Lending(bcode, rcode, ldate, rdate, state);
                addLendingToBeginning(lending); // Load lending to the beginning
            }
            System.out.println("Lending data loaded successfully.");
        } catch (Exception e) {
            System.out.println("Error loading lending data: " + e.getMessage());
        }
    }

    // Save lending data to file
    public void saveToFile(String fileName) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileName))) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Node<Lending> temp = head;
            while (temp != null) {
                Lending lending = temp.data;
                String rdateStr = (lending.rdate == null) ? "null" : sdf.format(lending.rdate);
                bw.write(String.format("%s,%s,%s,%s,%d\n", lending.bcode, lending.rcode, sdf.format(lending.ldate), rdateStr, lending.state));
                temp = temp.next;
            }
            System.out.println("Lending data saved successfully.");
        } catch (IOException e) {
            System.out.println("Error saving lending data: " + e.getMessage());
        }
    }

    // Display all lendings
    public void displayLendings() {
        Node<Lending> temp = head;
        if (temp == null) {
            System.out.println("No lendings in the list.");
            return;
        }
        while (temp != null) {
            System.out.println(temp.data);
            temp = temp.next;
        }
    }

    // Sort lendings by bcode and rcode
   public void sortLendings(boolean ascending) {
    if (head == null) return;

    Node<Lending> current = head, index = null;
    Lending temp;

    while (current != null) {
        index = current.next;
        while (index != null) {
            // Compare bcode first
            int bcodeComparison = current.data.bcode.compareTo(index.data.bcode);

            // Compare rcode if bcode is equal
            int rcodeComparison = current.data.rcode.compareTo(index.data.rcode);

            boolean shouldSwap;
            if (ascending) {
                shouldSwap = bcodeComparison > 0 || (bcodeComparison == 0 && rcodeComparison > 0);
            } else {
                shouldSwap = bcodeComparison < 0 || (bcodeComparison == 0 && rcodeComparison < 0);
            }

            if (shouldSwap) {
                temp = current.data;
                current.data = index.data;
                index.data = temp;
            }

            index = index.next;
        }
        current = current.next;
    }
    System.out.println("Lending list sorted successfully in " + (ascending ? "ascending" : "descending") + " order.");
}


 public void returnBook(String bcode, String rcode) {
        Node<Lending> temp = head;
        Date today = new Date();
        while (temp != null) {
            if (temp.data.bcode.equals(bcode) && temp.data.rcode.equals(rcode) && temp.data.state == 1) {
                temp.data.state = 2;
                temp.data.rdate = today;
                System.out.println("Book returned successfully.");
                return;
            }
            temp = temp.next;
        }
        System.out.println("Lending record not found or book already returned.");
    }

}
