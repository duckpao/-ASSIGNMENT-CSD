
public class Book {
    String bcode;
    String title;
    String author;
    String isbn;
    String publisher;
    int quantity;
    int lended; //lended <= quantity
    double price;

    public Book(String bcode, String title, String author, String isbn, String publisher, int quantity, int lended, double price) {
        this.bcode = bcode;
        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.publisher = publisher;
        this.quantity = quantity;
        this.lended = lended;
        this.price = price;
    }

    @Override
    public String toString() {
        return String.format("%-7s| %-30s| %-20s| %-20s| %-20s| %-10d| %-10d| $%.2f%n", bcode, title,author, isbn, publisher,quantity, lended, price);
    }
    
    public int compareTo(Book other) {
        return this.bcode.compareTo(other.bcode);
    }

    public String getBcode() {
        return bcode;
    }

    public void setBcode(String bcode) {
        this.bcode = bcode;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getLended() {
        return lended;
    }

    public void setLended(int lended) {
        this.lended = lended;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
    
    
}
