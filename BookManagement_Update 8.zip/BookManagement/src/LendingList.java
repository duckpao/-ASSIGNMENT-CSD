import java.io.*;
import java.time.LocalDate;
import java.util.Scanner;

public class LendingList {
    private Node<Lending> head;  // Head of the linked list

    public LendingList() {
        this.head = null;  // Initialize the head as null (empty list)
    }

    // 3.1 Load data from lendings.txt
    public void loadFromFile(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(", ");
                String bcode = data[0];
                String rcode = data[1];
                int state = Integer.parseInt(data[2]);
                LocalDate ldate = LocalDate.parse(data[3]);
                LocalDate rdate = data[4].equals("null") ? null : LocalDate.parse(data[4]);

                Lending lending = new Lending(bcode, rcode, state, ldate, rdate);
                addFirst(lending);  // Add lending to the beginning of the list
            }
            System.out.println("Lending data loaded successfully.");
        } catch (IOException e) {
            System.err.println("Error loading file: " + e.getMessage());
        }
    }

    // Add a lending record to the beginning of the list (like addFirst)
    public void addFirst(Lending lending) {
        Node<Lending> newNode = new Node<>(lending);  // Create a new node
        newNode.next = head;  // The new node points to the current head
        head = newNode;  // Update the head to be the new node
    }

    // 3.2 Lend book
    public void lendBook(String bcode, String rcode, BookList bookList, ReaderList readerList) {
     
        
        Book book = bookList.searchByBcode(bcode);
        Reader reader = readerList.searchByRcode(rcode);

        if (book == null || reader == null) {
            System.out.println("Book or reader not found.");
            return;
        }

        if (book.getQuantity() <= 0) {
            System.out.println("Book not available for lending.");
            return;
        }

        // Set lending information
        Lending newLending = new Lending(bcode, rcode, 1, LocalDate.now(), null);
        addFirst(newLending);  // Add to the beginning of the list

        // Update book quantity and lended count
        book.setQuantity(book.getQuantity() - 1);
        book.setLended(book.getLended() + 1);

        System.out.println("Book lent successfully.");
    }

    // 3.3 Display all lending books
    public void displayLendings() {
        if (head == null) {
            System.out.println("No lending records available.");
        } else {
            Node<Lending> current = head;
            while (current != null) {
                System.out.println(current.data);
                current = current.next;
            }
        }
    }

    // 3.4 Save lending list to file
    public void saveToFile(String filename) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(filename))) {
            Node<Lending> current = head;
            while (current != null) {
                pw.println(current.data.toString());
                current = current.next;
            }
            System.out.println("Lending list saved successfully.");
        } catch (IOException e) {
            System.err.println("Error saving to file: " + e.getMessage());
        }
    }

    // 3.5 Sort by bcode + rcode (using bubble sort for simplicity)
   public void sortByBcodeRcode() {
    if (head == null || head.next == null) return;  // List is empty or has only one node

    boolean swapped;
    do {
        swapped = false;
        Node<Lending> current = head;

        while (current != null && current.next != null) {
            Lending currentData = current.data;
            Lending nextData = current.next.data;

            // Compare by bcode first, then by rcode if bcode is the same
            boolean shouldSwap = currentData.bcode.compareTo(nextData.bcode) > 0 || 
                                (currentData.bcode.equals(nextData.bcode) && currentData.rcode.compareTo(nextData.rcode) > 0);

            if (shouldSwap) {
                // Swap the data between current and next
                Lending temp = current.data;
                current.data = current.next.data;
                current.next.data = temp;
                swapped = true;
            }

            current = current.next;  // Move to the next node
        }
    } while (swapped);

    System.out.println("Lending list sorted by bcode and rcode.");
}

    // 3.6 Return book by bcode and rcode
    public void returnBook(String bcode, String rcode, BookList bookList) {
        Node<Lending> current = head;
        while (current != null) {
            Lending lending = current.data;
            if (lending.bcode.equals(bcode) && lending.rcode.equals(rcode) && lending.state == 1) {
                lending.state = 2;  // Update state to returned
                lending.rdate = LocalDate.now();  // Set the return date to today

                // Update book quantity
                Book book = bookList.searchByBcode(bcode);
                if (book != null) {
                    book.setQuantity(book.getQuantity() + 1);
                    book.setLended(book.getLended() - 1);
                }

                System.out.println("Book returned successfully.");
                return;
            }
            current = current.next;
        }
        System.out.println("Lending record not found or book already returned.");
    }
}
