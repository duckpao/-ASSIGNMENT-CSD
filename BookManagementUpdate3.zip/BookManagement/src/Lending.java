import java.util.Date;

class Lending {
    String bcode;
    String rcode;
    Date ldate;
    Date rdate;
    int state;  // 1 = borrowed, 2 = returned

    public Lending(String bcode, String rcode, Date ldate, Date rdate, int state) {
        this.bcode = bcode;
        this.rcode = rcode;
        this.ldate = ldate;
        this.rdate = rdate;
        this.state = state;
    }

    @Override
    public String toString() {
        return String.format("Book Code: %s, Reader Code: %s, Lend Date: %s, Return Date: %s, State: %d", 
                             bcode, rcode, ldate, (rdate == null ? "Not returned" : rdate.toString()), state);
    }
}
