
import java.io.*;
import java.util.*;

public class BookList {

    Node<Book> head;
    Node<Book> tail;

    public BookList() {
        head = null;
        tail = null;
    }

    boolean isEmpty() {
        return (head == null);
    }

    void clear() {
        head = null;
        tail = null;
    }

    public int getInt(String msg) {
        Scanner sc = new Scanner(System.in);
        int result;
        do {
            try {
                System.out.println(msg);
                String in = sc.nextLine();
                if (in.matches("\\d+[\\.][0]+")) {
                    return Integer.parseInt(in.substring(0, in.indexOf(".")));
                }
                result = Integer.parseInt(in);
                if (result <= 0) {
                    System.out.println("Invalid number. Number must be greater than or equal to 1");
                    continue;
                }
                return result;
            } catch (NumberFormatException e) {
                System.out.println("Invalid format number. Please try again!");
            }
        } while (true);

    }

    public String getString(String msg) {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.print(msg);
            String in = sc.nextLine().trim();
            if (in.isEmpty()) {
                System.out.println("Input cannot be empty. Please try again.");
            } else {
                return in;
            }
        }
    }

    public void loadDataFromFile(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 8) {
                    String bcode = parts[0];
                    String title = parts[1];
                    String author = parts[2];
                    String isbn = parts[3];
                    String publisher = parts[4];
                    int quantity = Integer.parseInt(parts[5]);
                    int lended = Integer.parseInt(parts[6]);
                    double price = Double.parseDouble(parts[7]);

                    Book book = new Book(bcode, title, author, isbn, publisher, quantity, lended, price);

                    addLast(book);
                }
            }
        } catch (Exception e) {
            System.out.println("Error loading file: " + e.getMessage());
        }
    }

    // Method to load existing books from a file into a Set
    public Set<String> loadExistingBooks(String filename) {
        Set<String> existingBooks = new HashSet<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] bookData = line.split(",");
                if (bookData.length == 8) {
                    String bcode = bookData[0];
                    existingBooks.add(bcode); // Add bcode to the set
                }
            }
        } catch (Exception e) {
            System.out.println("Error reading from file: " + e.getMessage());
        }
        return existingBooks;
    }

    // Method to save new books to the file, avoiding duplicates
    public void saveToFile(String filename) {
        Set<String> existingBooks = loadExistingBooks(filename); // Load existing books
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filename, true))) {
            Node<Book> current = head;
            while (current != null) {
                Book book = current.data;

                // Check if the book already exists in the file
                if (!existingBooks.contains(book.bcode)) {
                    bw.write(book.bcode + "," + book.title + "," + book.author + "," + book.isbn + ","
                            + book.publisher + "," + book.quantity + "," + book.lended + "," + book.price);
                    bw.newLine(); // Move to the next line in the file
                    existingBooks.add(book.bcode); // Add to the set to prevent future duplicates
                }

                current = current.next;
            }
            System.out.println("Book list saved successfully to " + filename);
        } catch (Exception e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
    }

    // Display list book
    public void display() {
        if (head == null) {
            System.out.println("Book list is empty.");
            return;
        }
        Node<Book> current = head;
        System.out.printf("%-7s| %-30s| %-20s| %-20s| %-20s| %-10s| %-10s| %s%n",
                "Bcode", "Title", "Author", "Isbn", "Publisher", "Quantity", "Lended", "Price");
        System.out.println("---------------------------------------------------------------------------------------------------------------------------------------------------");
        while (current != null) {
            System.out.print(current.data);
            current = current.next;
        }
    }

    // Add book to the end of the list
    void addLast(Book x) {
        Node<Book> p = new Node(x);
        if (isEmpty()) {
            head = p;
            tail = p;
        } else {
            tail.next = p;
            tail = p;
        }
    }

    // Add book 
    void addFirst(Book x) {
        Node<Book> p = new Node<>(x);
        p.next = head;
        head = p;
        System.out.println("Book added successfully to the beggining");

    }

    // Search book by bcode
    public Book searchByBcode(String bcode) {
        Node<Book> current = head;
        while (current != null) {
            if (current.data.bcode.compareToIgnoreCase(bcode) == 0) {
                return current.data;
            }
            current = current.next;
        }
        return null;
    }

    // Display book searched by bcode
    public void displayByBcode(String bcode) {
        Book foundBook = searchByBcode(bcode);
        if (foundBook != null) {
            System.out.println("Book found: " + foundBook);
        } else {
            System.out.println("Book with bcode " + bcode + " not found.");
        }
    }

    Node getPrev(Node p) {
        if (isEmpty()) {
            return null;
        }
        if (p == head) {
            return null;
        }
        Node q = head;
        while (q != null && q.next != p) {
            q = q.next;

        }
        return q;
    }

    void removeFirst() {
        if (head == tail) {
            clear();
        }
        Node p = head;
        head = head.next;
        p.next = null;
    }

    void removeLast() {
        if (head == tail) {
            clear();
        }

        Node p = head;
        while (p != tail) {
            p = p.next;
        }
        p.next = null;
        tail = p;
    }

    void remove(Book x) {
    if (isEmpty()) {
        System.out.println("List is empty, nothing to remove.");
        return;
    }

    // Check if the head contains the book to be removed
    if (head.data.equals(x)) {
        removeFirst(); // Handle removal of the head
        return;
    }

    // Traverse the list to find the node
    Node<Book> current = head;
    Node<Book> prev = null;

    while (current != null) {
        if (current.data.equals(x)) {
            // If this is the tail node, handle tail removal
            if (current == tail) {
                removeLast(); // Remove the last element (tail)
            } else {
                // Bypass the current node for middle elements
                prev.next = current.next;
            }
            System.out.println("Book removed successfully.");
            return;
        }

        prev = current;
        current = current.next;
    }

    // If book is not found in the list
    System.out.println("Book not found in the list.");
}


    public void removeByBcode(String bcode) {
    if (isEmpty()) {
        System.out.println("The book list is empty. Nothing to remove.");
        return;
    }

    // Search for the book by its bcode
    Book bookToRemove = searchByBcode(bcode);
    
    // Check if the book exists in the list
    if (bookToRemove != null) {
        // Check if the book is being lent
        if (bookToRemove.lended > 0) {
            System.out.println("Cannot remove book with bcode " + bcode + " because it is being lent.");
        } else {
            // Remove the book from the list
            remove(bookToRemove);
            System.out.println("Book with bcode " + bcode + " has been removed successfully.");
        }
    } else {
        System.out.println("Cannot find book with bcode " + bcode + ".");
    }
}



    void swap(Node<Book> p, Node<Book> q) {
        Book temp = p.data;
        p.data = q.data;
        q.data = temp;
    }

    public void sortByBcode() {
        Node<Book> p = head;
        while (p != null) {
            Node<Book> q = p.next;
            while (q != null) {
                if (p.data.bcode.compareTo(q.data.bcode) > 0) {
                    swap(p, q);
                }
                q = q.next;
            }
            p = p.next;
        }
    }

    // Search book by title
    public void searchByTitle(String title) {
        if (title == null || title.isEmpty()) {
            System.out.println("Please enter a valid title to search");
            return;
        }

        boolean found = false;
        Node<Book> current = head;

        System.out.println("Books with title containing: " + title);

        while (current != null) {
            if (current.data.title.toLowerCase().contains(title.toLowerCase())) {
                System.out.println(current.data);
                found = true;
            }
            current = current.next;
        }

        if (!found) {
            System.out.println("There is not book with title: " + title);
        }

    }

    // Input book's information
    public Book inputBookDetails(Scanner sc) {
        String bcode;
        while (true) {
            bcode = getString("Enter bcode:");

            if (searchByBcode(bcode) != null) {
                System.out.println("Bcode already exists. Please enter a different bcode.");
            } else {
                break;
            }
        }
        String title = getString("Enter title:");

        String author = getString("Enter author:");

        String isbn = getString("Enter ISBN:");

        String publisher = getString("Enter publisher:");

        int quantity = getInt("Enter quantity:");

        int lended;
        while (true) {
            lended = getInt("Enter lended:");
            if (lended > quantity) {
                System.out.println("Lended must be less than or equal to quantity~");
            } else {
                break;
            }
        }

        double price;
        while (true) {
            System.out.println("Enter price:");
            if (sc.hasNextDouble()) {
                price = sc.nextDouble();
                if (price < 0) {
                    System.out.println("Price must be equal or greater than 0");
                    continue;
                }
                break;
            } else {
                System.out.println("Invalid input. Price is digit");
                sc.next();
            }

        }
        sc.nextLine();

        return new Book(bcode, title, author, isbn, publisher, quantity, lended, price);
    }

    // Add book after position k
    public void addAfterPositionK(int k, Book book) {
        if (k < 0) {
            System.out.println("Invalid position. Position must be equal or greater than 0~~");
        }
        Node<Book> current = head;
        int index = 0;

        while (current != null && index < k) {
            current = current.next;
            index++;
        }

        if (current == null) {
            System.out.println("Position " + k + " is out of bounds.");
            return;
        }

        Node<Book> newNode = new Node<>(book);
        newNode.next = current.next;
        current.next = newNode;

        System.out.println("Book added successfully after position " + k);
    }

    // Get book base on index
    Node<Book> getByIndex(int index) {
        Node<Book> p = head;
        int i = 0;
        while (i != index) {
            p = p.next;
            i++;
        }
        return p;
    }

    // Delete the book to the position k of the list
    public void deleteByPositionK(int k) {
        // Check if the list is empty
        if (isEmpty()) {
            System.out.println("List is empty, nothing to remove.");
            return;
        }

        // Traverse the list to make sure k is a valid position
        Node<Book> current = head;
        int index = 0;

        // If k is 0, remove the first element
        if (k == 0) {
            removeFirst();
            System.out.println("Node at position 0 removed successfully.");
            return;
        }

        // Traverse the list to find the node at position k
        Node<Book> prev = null;
        while (current != null) {
            if (index == k) {
                // If current is the tail, remove the last element
                if (current == tail) {
                    removeLast();
                } // Otherwise, remove the node from the middle
                else if (prev != null) {
                    prev.next = current.next; // Bypass the current node
                }
                System.out.println("Node at position " + k + " removed successfully.");
                return;
            }

            // Move to the next node
            prev = current;
            current = current.next;
            index++;
        }

        // If we reach here, k is out of bounds
        System.out.println("Invalid position! No node exists at position " + k + ".");
    }

}
